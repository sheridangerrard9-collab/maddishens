import { Nav } from "@/components/Nav";
import { Hero } from "@/components/Hero";
import { AboutDay } from "@/components/AboutDay";
import { EventDetails } from "@/components/EventDetails";
import { Itinerary } from "@/components/Itinerary";
import { WhatToBring } from "@/components/WhatToBring";
import { FAQ } from "@/components/FAQ";
import { RSVPSection } from "@/components/RSVPSection";
import { MoodBoard } from "@/components/MoodBoard";
import { Footer } from "@/components/Footer";
import { ChampagneProgress } from "@/components/ChampagneProgress";

export default function HomePage() {
  return (
    <>
      <Nav />
      <ChampagneProgress />
      <main id="main-content">
        <Hero />
        <AboutDay />
        <EventDetails />
        <Itinerary />
        <WhatToBring />
        <FAQ />
        <RSVPSection />
        <MoodBoard />
      </main>
      <Footer />
    </>
  );
}
