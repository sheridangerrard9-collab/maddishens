import { NextRequest, NextResponse } from "next/server";

/**
 * RSVP submission endpoint.
 *
 * Deliberately provider-agnostic: the request body is validated once, then
 * handed to whichever storage backend is configured via RSVP_PROVIDER, so
 * the host can switch between Google Sheets, Supabase and Airtable (or add
 * a new one) without touching the RSVP form itself.
 */

interface RsvpPayload {
  firstName: string;
  lastName: string;
  email: string;
  mobile: string;
  attending: "yes" | "no";
  dietary?: string;
  allergies?: string;
  songRequest?: string;
  emergencyContact?: string;
  notes?: string;
}

function isValidPayload(body: unknown): body is RsvpPayload {
  if (!body || typeof body !== "object") return false;
  const b = body as Record<string, unknown>;
  return (
    typeof b.firstName === "string" &&
    b.firstName.trim().length > 0 &&
    typeof b.lastName === "string" &&
    b.lastName.trim().length > 0 &&
    typeof b.email === "string" &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(b.email) &&
    typeof b.mobile === "string" &&
    b.mobile.trim().length > 0 &&
    (b.attending === "yes" || b.attending === "no")
  );
}

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  if (!isValidPayload(body)) {
    return NextResponse.json(
      { error: "Please fill in all required fields correctly." },
      { status: 400 }
    );
  }

  const record = {
    ...body,
    submittedAt: new Date().toISOString(),
  };

  const provider = process.env.RSVP_PROVIDER ?? "console";

  try {
    switch (provider) {
      case "sheets":
        await submitToGoogleSheets(record);
        break;
      case "supabase":
        await submitToSupabase(record);
        break;
      case "airtable":
        await submitToAirtable(record);
        break;
      default:
        // No backend configured yet — log so submissions aren't silently lost
        // during local development or before setup is finished.
        console.log("[RSVP submission — console provider]", record);
    }
  } catch (err) {
    console.error("RSVP submission failed:", err);
    return NextResponse.json(
      { error: "We couldn't save your RSVP right now. Please try again shortly." },
      { status: 502 }
    );
  }

  return NextResponse.json({ success: true });
}

/** Option 1: Google Sheets, via a Google Apps Script Web App acting as a webhook. */
async function submitToGoogleSheets(record: Record<string, unknown>) {
  const url = process.env.GOOGLE_SHEETS_WEBHOOK_URL;
  if (!url) throw new Error("GOOGLE_SHEETS_WEBHOOK_URL is not configured.");

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(record),
  });
  if (!res.ok) throw new Error(`Google Sheets webhook returned ${res.status}`);
}

/** Option 2: Supabase table insert via REST (no extra SDK dependency needed). */
async function submitToSupabase(record: Record<string, unknown>) {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Supabase environment variables are not configured.");

  const res = await fetch(`${url}/rest/v1/rsvps`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: key,
      Authorization: `Bearer ${key}`,
      Prefer: "return=minimal",
    },
    body: JSON.stringify(record),
  });
  if (!res.ok) throw new Error(`Supabase insert returned ${res.status}`);
}

/** Option 3: Airtable record creation via REST API. */
async function submitToAirtable(record: Record<string, unknown>) {
  const apiKey = process.env.AIRTABLE_API_KEY;
  const baseId = process.env.AIRTABLE_BASE_ID;
  const table = process.env.AIRTABLE_TABLE_NAME ?? "RSVPs";
  if (!apiKey || !baseId) throw new Error("Airtable environment variables are not configured.");

  const res = await fetch(
    `https://api.airtable.com/v0/${baseId}/${encodeURIComponent(table)}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ fields: record }),
    }
  );
  if (!res.ok) throw new Error(`Airtable insert returned ${res.status}`);
}
