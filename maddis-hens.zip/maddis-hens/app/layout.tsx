import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Inter } from "next/font/google";
import "./globals.css";

// Luxury serif for display type, paired with a clean grotesque for body copy.
const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-cormorant",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  variable: "--font-inter",
  display: "swap",
});

const siteUrl = "https://maddis-hens.vercel.app";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: "Maddi's Hens — A Day of Celebration",
  description:
    "Join us for Maddi's Hens Day — a day of celebration, champagne, laughter and unforgettable memories. View event details and RSVP.",
  robots: {
    // This is a private guest-list event, so keep it out of search results.
    index: false,
    follow: false,
  },
  openGraph: {
    title: "Maddi's Hens",
    description:
      "A day of celebration, champagne, laughter and unforgettable memories.",
    url: siteUrl,
    siteName: "Maddi's Hens",
    images: [{ url: "/og-image.jpg", width: 1200, height: 630 }],
    locale: "en_AU",
    type: "website",
  },
  icons: {
    icon: "/favicon.ico",
  },
};

export const viewport: Viewport = {
  themeColor: "#6D2736",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en-AU" className={`${cormorant.variable} ${inter.variable}`}>
      <body>
        {/* Skip link for keyboard / screen-reader users */}
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-burgundy focus:px-6 focus:py-3 focus:text-cream"
        >
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}
