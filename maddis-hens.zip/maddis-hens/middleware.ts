import { NextRequest, NextResponse } from "next/server";

/**
 * Optional guest-list password gate.
 * If SITE_PASSWORD is set in the environment, visitors are prompted for
 * basic-auth credentials (any username, password = SITE_PASSWORD) before
 * they can view the site. Leave SITE_PASSWORD unset to make the site public.
 */
export function middleware(req: NextRequest) {
  const sitePassword = process.env.SITE_PASSWORD;
  if (!sitePassword) return NextResponse.next();

  const authHeader = req.headers.get("authorization");

  if (authHeader) {
    const [, encoded] = authHeader.split(" ");
    const decoded = Buffer.from(encoded, "base64").toString();
    const [, password] = decoded.split(":");
    if (password === sitePassword) {
      return NextResponse.next();
    }
  }

  return new NextResponse("Authentication required.", {
    status: 401,
    headers: { "WWW-Authenticate": 'Basic realm="Maddi\'s Hens"' },
  });
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
};
