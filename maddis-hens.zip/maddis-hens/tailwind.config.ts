import type { Config } from "tailwindcss";

// Design tokens for Maddi's Hens — a sophisticated European-summer / editorial
// bridal aesthetic. Colours pulled directly from the client brief.
const config: Config = {
  darkMode: ["class"],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        burgundy: {
          DEFAULT: "#6D2736",
          50: "#F7ECEE",
          100: "#EED8DC",
          200: "#D9AEB6",
          300: "#C3838F",
          400: "#A15265",
          500: "#6D2736",
          600: "#5C202D",
          700: "#4A1A24",
          800: "#38131B",
          900: "#260D12",
        },
        babyblue: {
          DEFAULT: "#C8DAF0",
          50: "#F5F9FD",
          100: "#EAF1FA",
          200: "#DCE9F5",
          300: "#C8DAF0",
          400: "#A7C3E5",
          500: "#84AAD8",
        },
        cream: {
          DEFAULT: "#F7F2EA",
          soft: "#FBF8F3",
        },
        ink: "#2E2A2A",
        sand: "#EDE6DD",
      },
      fontFamily: {
        display: ["var(--font-cormorant)", "Georgia", "serif"],
        body: ["var(--font-inter)", "Helvetica", "Arial", "sans-serif"],
      },
      letterSpacing: {
        widest2: "0.35em",
      },
      maxWidth: {
        editorial: "1180px",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(24px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0) rotate(0deg)" },
          "50%": { transform: "translateY(-14px) rotate(1.5deg)" },
        },
        "float-slow": {
          "0%, 100%": { transform: "translateY(0) rotate(0deg)" },
          "50%": { transform: "translateY(-10px) rotate(-2deg)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "0% 50%" },
          "100%": { backgroundPosition: "100% 50%" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.9s cubic-bezier(0.22,1,0.36,1) both",
        float: "float 7s ease-in-out infinite",
        "float-slow": "float-slow 10s ease-in-out infinite",
        shimmer: "shimmer 3s linear infinite",
      },
      boxShadow: {
        soft: "0 20px 60px -20px rgba(109,39,54,0.18)",
        card: "0 8px 30px -12px rgba(46,42,42,0.12)",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
export default config;
