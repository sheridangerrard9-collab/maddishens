"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";

/**
 * Wraps children in a subtle fade-up reveal that triggers once when the
 * element scrolls into view. Kept restrained per the brief: no bounce,
 * no exaggerated motion — just a gentle, premium settle into place.
 */
export function FadeIn({
  children,
  delay = 0,
  className,
  y = 24,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  y?: number;
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}
