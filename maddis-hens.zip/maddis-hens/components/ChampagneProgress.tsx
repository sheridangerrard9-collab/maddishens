"use client";

import { motion, useScroll, useSpring, useTransform } from "framer-motion";

/**
 * SIGNATURE ELEMENT.
 * A hand-drawn champagne coupe fixed to the edge of the viewport that fills
 * with "champagne" as the guest scrolls down the page — by the time they
 * reach the RSVP section, the glass is full. A small, tasteful nod to the
 * site's champagne motif that also does a real job (scroll progress),
 * rather than existing as pure decoration.
 *
 * Hidden on small screens to keep mobile layouts clean and uncluttered.
 */
export function ChampagneProgress() {
  const { scrollYProgress } = useScroll();
  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 80,
    damping: 24,
    mass: 0.3,
  });

  // The liquid fill is a clipped rect whose height grows with scroll
  // progress, from 0 (empty, y=76) up to ~56 (near the rim, y=20).
  const fillHeight = useTransform(smoothProgress, [0, 1], [0, 56]);
  const fillY = useTransform(fillHeight, (h) => 76 - h);

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed bottom-8 right-6 z-40 hidden md:block"
    >
      <svg viewBox="0 0 60 100" width="34" height="58" className="drop-shadow-sm">
        <defs>
          <clipPath id="glassClip">
            <path d="M30 8C14 8 12 24 18 34C22 41 28 44 28 50V80H32V50C32 44 38 41 42 34C48 24 46 8 30 8Z" />
          </clipPath>
        </defs>

        {/* Champagne liquid, clipped to the glass silhouette */}
        <motion.rect
          x="14"
          width="32"
          y={fillY}
          height={fillHeight}
          fill="#C8DAF0"
          opacity={0.85}
          clipPath="url(#glassClip)"
        />

        {/* Glass outline on top */}
        <g
          fill="none"
          stroke="#6D2736"
          strokeWidth="1.4"
          strokeLinecap="round"
          opacity={0.85}
        >
          <path d="M30 8C14 8 12 24 18 34C22 41 28 44 28 50V80" />
          <path d="M30 8C46 8 48 24 42 34C38 41 32 44 32 50V80" />
          <path d="M20 88H40" />
          <path d="M30 80V88" />
        </g>
      </svg>
      <span className="sr-only">Scroll progress indicator</span>
    </div>
  );
}
