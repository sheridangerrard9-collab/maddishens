import { FadeIn } from "./FadeIn";
import { RSVPForm } from "./RSVPForm";
import { Countdown } from "./Countdown";
import { SaveToCalendar } from "./SaveToCalendar";

export function RSVPSection() {
  return (
    <section id="rsvp" className="relative bg-cream py-28 md:py-36">
      <div className="mx-auto max-w-editorial px-6 md:px-10">
        <FadeIn className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Save your seat</span>
          <h2 className="section-heading mt-4">RSVP</h2>
          <p className="mt-5 font-body text-base text-ink/70 md:text-lg">
            Please respond by the date below so we can finalise catering and
            transport — we can&rsquo;t wait to celebrate with you.
          </p>
        </FadeIn>

        <FadeIn delay={0.1} className="mt-10 flex flex-col items-center gap-6">
          <Countdown />
          <SaveToCalendar />
        </FadeIn>

        <FadeIn delay={0.15} className="mt-14">
          <RSVPForm />
        </FadeIn>
      </div>
    </section>
  );
}
