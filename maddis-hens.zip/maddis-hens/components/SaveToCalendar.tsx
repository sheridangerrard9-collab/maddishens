"use client";

import { CalendarPlus } from "lucide-react";
import { buildIcsFile, event } from "@/lib/event";

/** Generates a .ics file client-side and triggers a download — no server needed. */
export function SaveToCalendar() {
  function handleClick() {
    const ics = buildIcsFile();
    const blob = new Blob([ics], { type: "text/calendar;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${event.title.replace(/[^a-z0-9]/gi, "-")}.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      className="inline-flex items-center gap-2 rounded-full border border-burgundy/30 px-5 py-2.5 text-sm text-burgundy transition-colors hover:bg-burgundy/5"
    >
      <CalendarPlus className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
      Save to Calendar
    </button>
  );
}
