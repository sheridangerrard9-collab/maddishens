import { RoseSprig } from "./LineArt";
import { event } from "@/lib/event";

export function Footer() {
  return (
    <footer className="bg-cream py-16 text-center">
      <RoseSprig className="mx-auto h-14 w-8 text-burgundy/40" />
      <p className="mt-6 font-display text-xl text-burgundy">
        Made with love for Maddi&rsquo;s Hens
      </p>
      <p className="mt-2 font-body text-xs text-ink/50">
        Questions? {event.contactName} —{" "}
        <a
          href={`mailto:${event.contactEmail}`}
          className="underline underline-offset-4 hover:text-burgundy"
        >
          {event.contactEmail}
        </a>
      </p>
    </footer>
  );
}
