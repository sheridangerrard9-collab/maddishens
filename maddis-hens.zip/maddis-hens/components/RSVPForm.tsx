"use client";

import { useState, type FormEvent } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, Loader2 } from "lucide-react";

type Attending = "yes" | "no" | "";

interface RsvpData {
  firstName: string;
  lastName: string;
  email: string;
  mobile: string;
  attending: Attending;
  dietary: string;
  allergies: string;
  songRequest: string;
  emergencyContact: string;
  notes: string;
}

const initialData: RsvpData = {
  firstName: "",
  lastName: "",
  email: "",
  mobile: "",
  attending: "",
  dietary: "",
  allergies: "",
  songRequest: "",
  emergencyContact: "",
  notes: "",
};

type Status = "idle" | "loading" | "success" | "error";

export function RSVPForm() {
  const [data, setData] = useState<RsvpData>(initialData);
  const [errors, setErrors] = useState<Partial<Record<keyof RsvpData, string>>>({});
  const [status, setStatus] = useState<Status>("idle");
  const [errorMessage, setErrorMessage] = useState("");

  function update<K extends keyof RsvpData>(key: K, value: RsvpData[K]) {
    setData((prev) => ({ ...prev, [key]: value }));
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: undefined }));
  }

  function validate(): boolean {
    const next: Partial<Record<keyof RsvpData, string>> = {};

    if (!data.firstName.trim()) next.firstName = "Please enter your first name.";
    if (!data.lastName.trim()) next.lastName = "Please enter your last name.";

    if (!data.email.trim()) {
      next.email = "Please enter your email.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      next.email = "That email doesn't look quite right.";
    }

    if (!data.mobile.trim()) {
      next.mobile = "Please enter a mobile number.";
    } else if (!/^[0-9+()\s-]{6,20}$/.test(data.mobile)) {
      next.mobile = "That mobile number doesn't look quite right.";
    }

    if (!data.attending) next.attending = "Please let us know if you can make it.";

    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!validate()) return;

    setStatus("loading");
    setErrorMessage("");

    try {
      const res = await fetch("/api/rsvp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => null);
        throw new Error(body?.error ?? "Something went wrong submitting your RSVP.");
      }

      setStatus("success");
    } catch (err) {
      setStatus("error");
      setErrorMessage(
        err instanceof Error
          ? err.message
          : "Something went wrong. Please try again."
      );
    }
  }

  if (status === "success") {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="mx-auto max-w-md rounded-3xl border border-burgundy/10 bg-cream px-8 py-14 text-center shadow-soft"
        role="status"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.15, type: "spring", stiffness: 200, damping: 14 }}
          className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-babyblue-200"
        >
          <CheckCircle2 className="h-8 w-8 text-burgundy" strokeWidth={1.5} />
        </motion.div>
        <h3 className="mt-6 font-display text-2xl font-medium text-burgundy">
          {data.attending === "yes" ? "You're on the list!" : "Thanks for letting us know"}
        </h3>
        <p className="mt-3 font-body text-sm text-ink/70 md:text-base">
          {data.attending === "yes"
            ? `Thank you, ${data.firstName} — we can't wait to celebrate with you. A confirmation has been sent to ${data.email}.`
            : `Thanks for the RSVP, ${data.firstName}. You'll be missed — we'll be thinking of you on the day.`}
        </p>
        <button
          type="button"
          onClick={() => {
            setData(initialData);
            setStatus("idle");
          }}
          className="mt-8 text-sm text-burgundy underline underline-offset-4"
        >
          Submit another response
        </button>
      </motion.div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="mx-auto max-w-2xl space-y-6 rounded-3xl border border-burgundy/10 bg-cream p-6 shadow-soft sm:p-10"
      aria-describedby={status === "error" ? "rsvp-form-error" : undefined}
    >
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <Field
          label="First name"
          id="firstName"
          required
          value={data.firstName}
          onChange={(v) => update("firstName", v)}
          error={errors.firstName}
          autoComplete="given-name"
        />
        <Field
          label="Last name"
          id="lastName"
          required
          value={data.lastName}
          onChange={(v) => update("lastName", v)}
          error={errors.lastName}
          autoComplete="family-name"
        />
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <Field
          label="Email"
          id="email"
          type="email"
          required
          value={data.email}
          onChange={(v) => update("email", v)}
          error={errors.email}
          autoComplete="email"
        />
        <Field
          label="Mobile number"
          id="mobile"
          type="tel"
          required
          value={data.mobile}
          onChange={(v) => update("mobile", v)}
          error={errors.mobile}
          autoComplete="tel"
        />
      </div>

      <fieldset>
        <legend className="mb-3 font-body text-sm font-medium text-ink">
          Will you be attending? <span className="text-burgundy">*</span>
        </legend>
        <div className="flex gap-4" role="radiogroup" aria-describedby={errors.attending ? "attending-error" : undefined}>
          {(["yes", "no"] as const).map((val) => (
            <label
              key={val}
              className={`flex flex-1 cursor-pointer items-center justify-center rounded-xl border px-4 py-3 text-sm font-medium transition-colors ${
                data.attending === val
                  ? "border-burgundy bg-burgundy text-cream"
                  : "border-burgundy/20 bg-transparent text-ink hover:border-burgundy/50"
              }`}
            >
              <input
                type="radio"
                name="attending"
                value={val}
                checked={data.attending === val}
                onChange={() => update("attending", val)}
                className="sr-only"
              />
              {val === "yes" ? "Joyfully accepts" : "Regretfully declines"}
            </label>
          ))}
        </div>
        {errors.attending && (
          <p id="attending-error" className="mt-2 text-xs text-burgundy-600">
            {errors.attending}
          </p>
        )}
      </fieldset>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <Field
          label="Dietary requirements"
          id="dietary"
          value={data.dietary}
          onChange={(v) => update("dietary", v)}
          placeholder="Vegetarian, gluten-free…"
        />
        <Field
          label="Allergies"
          id="allergies"
          value={data.allergies}
          onChange={(v) => update("allergies", v)}
          placeholder="Nuts, shellfish…"
        />
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <Field
          label="Song request"
          id="songRequest"
          value={data.songRequest}
          onChange={(v) => update("songRequest", v)}
          placeholder="What'll get you on the dance floor?"
        />
        <Field
          label="Emergency contact"
          id="emergencyContact"
          value={data.emergencyContact}
          onChange={(v) => update("emergencyContact", v)}
          placeholder="Name & number"
        />
      </div>

      <div>
        <label htmlFor="notes" className="mb-2 block font-body text-sm font-medium text-ink">
          Special notes
        </label>
        <textarea
          id="notes"
          rows={3}
          value={data.notes}
          onChange={(e) => update("notes", e.target.value)}
          placeholder="Anything else we should know?"
          className="w-full rounded-xl border border-burgundy/20 bg-cream-soft px-4 py-3 font-body text-sm text-ink placeholder:text-ink/40 focus:border-burgundy"
        />
      </div>

      <AnimatePresence>
        {status === "error" && (
          <motion.p
            id="rsvp-form-error"
            role="alert"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="rounded-xl bg-burgundy-50 px-4 py-3 text-sm text-burgundy-600"
          >
            {errorMessage}
          </motion.p>
        )}
      </AnimatePresence>

      <button
        type="submit"
        disabled={status === "loading"}
        className="btn-primary w-full disabled:cursor-not-allowed disabled:opacity-70"
      >
        {status === "loading" ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            Sending your RSVP…
          </>
        ) : (
          "Submit RSVP"
        )}
      </button>
    </form>
  );
}

function Field({
  label,
  id,
  value,
  onChange,
  error,
  required,
  type = "text",
  placeholder,
  autoComplete,
}: {
  label: string;
  id: string;
  value: string;
  onChange: (v: string) => void;
  error?: string;
  required?: boolean;
  type?: string;
  placeholder?: string;
  autoComplete?: string;
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-2 block font-body text-sm font-medium text-ink">
        {label} {required && <span className="text-burgundy">*</span>}
      </label>
      <input
        id={id}
        name={id}
        type={type}
        value={value}
        placeholder={placeholder}
        autoComplete={autoComplete}
        aria-required={required}
        aria-invalid={!!error}
        aria-describedby={error ? `${id}-error` : undefined}
        onChange={(e) => onChange(e.target.value)}
        className={`w-full rounded-xl border bg-cream-soft px-4 py-3 font-body text-sm text-ink placeholder:text-ink/40 focus:border-burgundy ${
          error ? "border-burgundy-500" : "border-burgundy/20"
        }`}
      />
      {error && (
        <p id={`${id}-error`} className="mt-1.5 text-xs text-burgundy-600">
          {error}
        </p>
      )}
    </div>
  );
}
