"use client";

import { useEffect, useState } from "react";
import { getEventDateTime } from "@/lib/event";

function getTimeLeft() {
  const diff = getEventDateTime().getTime() - Date.now();
  const clamp = Math.max(diff, 0);
  return {
    days: Math.floor(clamp / (1000 * 60 * 60 * 24)),
    hours: Math.floor((clamp / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((clamp / (1000 * 60)) % 60),
    seconds: Math.floor((clamp / 1000) % 60),
    isPast: diff <= 0,
  };
}

/**
 * Live countdown to the event. Renders nothing meaningful until mounted on
 * the client (avoids SSR/client clock mismatch), then ticks every second.
 */
export function Countdown() {
  const [time, setTime] = useState<ReturnType<typeof getTimeLeft> | null>(null);

  useEffect(() => {
    setTime(getTimeLeft());
    const id = setInterval(() => setTime(getTimeLeft()), 1000);
    return () => clearInterval(id);
  }, []);

  if (!time) {
    return <div className="h-[72px]" aria-hidden="true" />;
  }

  if (time.isPast) {
    return (
      <p className="font-display text-2xl text-burgundy">
        The celebration has begun! 🥂
      </p>
    );
  }

  const units = [
    { value: time.days, label: "Days" },
    { value: time.hours, label: "Hours" },
    { value: time.minutes, label: "Minutes" },
    { value: time.seconds, label: "Seconds" },
  ];

  return (
    <div
      role="timer"
      aria-live="off"
      aria-label={`${time.days} days, ${time.hours} hours, ${time.minutes} minutes and ${time.seconds} seconds until the event`}
      className="flex items-start gap-5 sm:gap-8"
    >
      {units.map((unit) => (
        <div key={unit.label} className="flex flex-col items-center">
          <span className="font-display text-4xl font-medium text-burgundy tabular-nums sm:text-5xl">
            {String(unit.value).padStart(2, "0")}
          </span>
          <span className="mt-1 text-[11px] uppercase tracking-widest2 text-ink/50">
            {unit.label}
          </span>
        </div>
      ))}
    </div>
  );
}
