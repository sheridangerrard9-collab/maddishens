"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";

const links = [
  { href: "#about", label: "The Day" },
  { href: "#details", label: "Details" },
  { href: "#itinerary", label: "Itinerary" },
  { href: "#faq", label: "FAQ" },
  { href: "#wearing", label: "Wearing" },
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ opacity: 0, y: -12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-cream-soft/90 shadow-card backdrop-blur-md"
          : "bg-transparent"
      }`}
    >
      <nav
        aria-label="Primary"
        className="mx-auto flex max-w-editorial items-center justify-between px-6 py-4 md:px-10"
      >
        <a
          href="#home"
          className="font-display text-xl font-medium tracking-wide text-burgundy"
        >
          Maddi&rsquo;s Hens
        </a>

        <ul className="hidden items-center gap-8 md:flex">
          {links.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="text-sm tracking-wide text-ink/70 transition-colors hover:text-burgundy"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <a
          href="#rsvp"
          className="rounded-full bg-burgundy px-5 py-2 text-sm tracking-wide text-cream transition-colors hover:bg-burgundy-600"
        >
          RSVP
        </a>
      </nav>
    </motion.header>
  );
}
