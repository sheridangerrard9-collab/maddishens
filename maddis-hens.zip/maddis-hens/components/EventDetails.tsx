import {
  CalendarDays,
  Clock,
  MapPin,
  Shirt,
  CloudSun,
  Car,
} from "lucide-react";
import { FadeIn } from "./FadeIn";
import { event, getFormattedDate } from "@/lib/event";

const details = [
  {
    icon: CalendarDays,
    label: "Date",
    value: getFormattedDate(),
  },
  {
    icon: Clock,
    label: "Time",
    value: `${event.startTime} — ${event.endTime}`,
  },
  {
    icon: MapPin,
    label: "Location",
    value: event.location,
  },
  {
    icon: Shirt,
    label: "Dress Code",
    value: event.dressCode,
  },
  {
    icon: CloudSun,
    label: "Weather",
    value:
      "Mostly outdoors with shaded areas — bring a light layer for the evening.",
  },
  {
    icon: Car,
    label: "Transport",
    value:
      "Shared transfers depart from the city at 10:15am. Details confirmed on RSVP.",
  },
];

export function EventDetails() {
  return (
    <section id="details" className="bg-sand/60 py-28 md:py-36">
      <div className="mx-auto max-w-editorial px-6 md:px-10">
        <FadeIn className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">The essentials</span>
          <h2 className="section-heading mt-4">Event Details</h2>
          <p className="mt-5 font-body text-base text-ink/70 md:text-lg">
            Everything you need to know before the day arrives.
          </p>
        </FadeIn>

        <div className="mt-16 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {details.map((detail, i) => (
            <FadeIn key={detail.label} delay={i * 0.08}>
              <div className="group h-full rounded-2xl border border-burgundy/10 bg-cream p-8 shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-soft">
                <detail.icon
                  className="h-6 w-6 text-burgundy/70"
                  strokeWidth={1.4}
                  aria-hidden="true"
                />
                <h3 className="mt-5 font-display text-xl font-medium text-burgundy">
                  {detail.label}
                </h3>
                <p className="mt-2 font-body text-sm leading-relaxed text-ink/70 md:text-base">
                  {detail.value}
                </p>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}
