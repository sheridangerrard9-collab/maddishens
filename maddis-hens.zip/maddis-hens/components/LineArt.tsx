/**
 * A small library of minimal, monoline hand-drawn illustrations used as
 * soft, low-opacity decorative elements throughout the site. All strokes
 * use `currentColor` so they can be tinted via a parent `text-*` class.
 * Purely decorative — marked aria-hidden.
 */

export function ChampagneGlass({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 60 100"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.2"
      strokeLinecap="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M30 8C14 8 12 24 18 34C22 41 28 44 28 50V80" />
      <path d="M30 8C46 8 48 24 42 34C38 41 32 44 32 50V80" />
      <path d="M18 62C22 65 38 65 42 62" opacity="0.6" />
      <path d="M18 68C22 70 38 70 42 68" opacity="0.6" />
      <path d="M20 88H40" />
      <path d="M30 80V88" />
      <circle cx="24" cy="20" r="0.8" fill="currentColor" stroke="none" opacity="0.7" />
      <circle cx="34" cy="26" r="0.6" fill="currentColor" stroke="none" opacity="0.7" />
      <circle cx="27" cy="15" r="0.5" fill="currentColor" stroke="none" opacity="0.7" />
    </svg>
  );
}

export function ChampagneBottle({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 50 110"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.2"
      strokeLinecap="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M22 4H28V18C28 18 35 24 35 34V96C35 101 31 104 25 104C19 104 15 101 15 96V34C15 24 22 18 22 18V4Z" />
      <path d="M15 40H35" opacity="0.5" />
      <path d="M18 60L32 62" opacity="0.4" />
      <path d="M18 70L32 68" opacity="0.4" />
      <path d="M22 4C22 2 28 2 28 4" />
    </svg>
  );
}

export function Peony({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      fill="none"
      stroke="currentColor"
      strokeWidth="1"
      strokeLinecap="round"
      className={className}
      aria-hidden="true"
    >
      <circle cx="50" cy="50" r="8" />
      <path d="M50 42C40 30 30 30 24 20C34 18 46 24 50 34" />
      <path d="M58 42C68 30 78 30 84 20C74 18 62 24 58 34" />
      <path d="M42 50C28 46 20 52 8 48C14 58 28 64 40 58" />
      <path d="M42 58C30 66 30 78 20 86C28 92 42 88 48 76" />
      <path d="M58 58C70 66 70 78 80 86C72 92 58 88 52 76" />
      <path d="M58 50C72 46 80 52 92 48C86 58 72 64 60 58" />
      <path d="M50 58C48 68 52 78 48 90C56 88 60 76 56 66" />
      <path d="M50 42C48 32 52 24 48 12C56 16 58 28 54 38" />
    </svg>
  );
}

export function RoseSprig({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 80 140"
      fill="none"
      stroke="currentColor"
      strokeWidth="1"
      strokeLinecap="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M40 20C46 26 46 34 40 40C34 34 34 26 40 20Z" />
      <circle cx="40" cy="28" r="6" />
      <path d="M40 40V130" />
      <path d="M40 60C30 56 24 62 16 60C22 68 32 70 40 66" />
      <path d="M40 80C50 76 56 82 64 80C58 88 48 90 40 86" />
      <path d="M40 100C30 96 24 102 16 100C22 108 32 110 40 106" />
      <path d="M16 60C16 60 12 66 14 72" opacity="0.6" />
      <path d="M64 80C64 80 68 86 66 92" opacity="0.6" />
    </svg>
  );
}

export function BowIllustration({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 60"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M50 30C50 30 46 12 28 12C14 12 10 22 20 28C28 32 40 30 50 30Z" />
      <path d="M50 30C50 30 54 12 72 12C86 12 90 22 80 28C72 32 60 30 50 30Z" />
      <circle cx="50" cy="30" r="5" />
      <path d="M46 34L30 52" />
      <path d="M54 34L70 52" />
    </svg>
  );
}
