"use client";

import { motion } from "framer-motion";
import { ChampagneGlass, Peony, RoseSprig } from "./LineArt";
import { getFormattedDate } from "@/lib/event";

export function Hero() {
  const formattedDate = getFormattedDate();

  return (
    <section
      id="home"
      className="relative flex min-h-[100svh] flex-col items-center justify-center overflow-hidden bg-cream px-6 text-center"
    >
      {/* Floating decorative line art — purely ambient, aria-hidden */}
      <Peony
        className="absolute -left-6 top-16 h-28 w-28 text-burgundy/15 animate-float-slow md:left-10 md:h-40 md:w-40"
      />
      <RoseSprig
        className="absolute -right-2 top-1/3 h-32 w-32 text-burgundy/15 animate-float md:right-16 md:h-48 md:w-48"
      />
      <ChampagneGlass
        className="absolute bottom-10 left-1/2 hidden h-24 w-24 -translate-x-[220px] text-burgundy/15 animate-float-slow md:block"
      />

      <motion.p
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="eyebrow mb-6"
      >
        {formattedDate}
      </motion.p>

      <motion.h1
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
        className="text-balance font-display text-6xl font-medium leading-[1.05] text-burgundy sm:text-7xl md:text-8xl"
      >
        Maddi&rsquo;s Hens
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
        className="mt-6 max-w-xl text-balance font-body text-lg font-light text-ink/80 md:text-xl"
      >
        A day of celebration, champagne, laughter and unforgettable memories.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="mt-10 flex flex-col gap-4 sm:flex-row"
      >
        <a href="#rsvp" className="btn-primary">
          RSVP Now
        </a>
        <a href="#details" className="btn-secondary">
          View Event Details
        </a>
      </motion.div>

      {/* Scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1 }}
        className="absolute bottom-8 flex flex-col items-center gap-2 text-burgundy/50"
      >
        <span className="text-[11px] uppercase tracking-widest2">Scroll</span>
        <span className="h-10 w-px bg-burgundy/30" />
      </motion.div>
    </section>
  );
}
