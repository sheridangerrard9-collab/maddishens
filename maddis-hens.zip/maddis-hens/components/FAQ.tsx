"use client";

import * as Accordion from "@radix-ui/react-accordion";
import { ChevronDown } from "lucide-react";
import { FadeIn } from "./FadeIn";
import { event } from "@/lib/event";

const faqs = [
  {
    q: "What should I wear?",
    a: `Think elevated and effortless — linen, soft neutrals, floaty fabrics. Dress code: ${event.dressCode}. Full outfit inspiration is in the "What We're Wearing" section below.`,
  },
  {
    q: "Is accommodation provided?",
    a: "A block of rooms has been held nearby for anyone travelling from out of town. Let us know if you'd like details when you RSVP, and we'll send them through directly.",
  },
  {
    q: "Can dietary requirements be accommodated?",
    a: "Absolutely — every meal is designed to flex around allergies and dietary needs. Just note yours in the RSVP form and the caterers will take care of the rest.",
  },
  {
    q: "What happens if it rains?",
    a: "The venue has a beautiful covered pavilion as a backup, so the celebration goes ahead rain or shine — just perhaps with fewer photos on the lawn.",
  },
  {
    q: "Can I bring a plus-one?",
    a: "This one is just for Maddi's closest circle, so the guest list is set. If you have any questions about who's invited, reach out to the contact below.",
  },
];

export function FAQ() {
  return (
    <section id="faq" className="bg-cream py-28 md:py-36">
      <div className="mx-auto max-w-2xl px-6 md:px-10">
        <FadeIn className="text-center">
          <span className="eyebrow">Good to know</span>
          <h2 className="section-heading mt-4">Frequently Asked</h2>
        </FadeIn>

        <FadeIn delay={0.1} className="mt-14">
          <Accordion.Root type="single" collapsible className="space-y-3">
            {faqs.map((faq) => (
              <Accordion.Item
                key={faq.q}
                value={faq.q}
                className="overflow-hidden rounded-2xl border border-burgundy/10 bg-sand/50"
              >
                <Accordion.Header>
                  <Accordion.Trigger className="group flex w-full items-center justify-between gap-4 px-6 py-5 text-left font-display text-lg font-medium text-burgundy transition-colors hover:bg-sand/80 md:text-xl">
                    {faq.q}
                    <ChevronDown
                      className="h-4 w-4 shrink-0 text-burgundy/60 transition-transform duration-300 group-data-[state=open]:rotate-180"
                      aria-hidden="true"
                    />
                  </Accordion.Trigger>
                </Accordion.Header>
                <Accordion.Content className="px-6 pb-5 font-body text-sm leading-relaxed text-ink/75 data-[state=open]:animate-fade-up md:text-base">
                  {faq.a}
                </Accordion.Content>
              </Accordion.Item>
            ))}
          </Accordion.Root>
        </FadeIn>

        <FadeIn delay={0.15} className="mt-14 text-center">
          <p className="font-body text-sm text-ink/60">
            Still have a question? Reach out to {event.contactName.split(" (")[0]}
          </p>
          <a
            href={`mailto:${event.contactEmail}`}
            className="mt-1 inline-block font-body text-sm text-burgundy underline underline-offset-4"
          >
            {event.contactEmail}
          </a>
        </FadeIn>
      </div>
    </section>
  );
}
