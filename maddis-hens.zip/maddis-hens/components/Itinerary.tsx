import { FadeIn } from "./FadeIn";

const schedule = [
  { time: "11:00am", title: "Welcome Drinks", note: "Arrival & bubbles on the lawn" },
  { time: "12:00pm", title: "Flower Crown Workshop", note: "A relaxed, hands-on activity" },
  { time: "2:00pm", title: "Long Lunch", note: "Seated, shared-plate feast" },
  { time: "4:00pm", title: "Champagne Session", note: "Tastings & toasts" },
  { time: "6:00pm", title: "Dinner", note: "Golden-hour tablescape" },
  { time: "8:00pm", title: "Celebrations Continue", note: "Music, dancing, dessert" },
];

export function Itinerary() {
  return (
    <section id="itinerary" className="bg-cream py-28 md:py-36">
      <div className="mx-auto max-w-editorial px-6 md:px-10">
        <FadeIn className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Order of the day</span>
          <h2 className="section-heading mt-4">Itinerary</h2>
        </FadeIn>

        {/* Timeline is a real chronological sequence, so numbered/ordered
            markers genuinely carry information here. */}
        <div className="relative mx-auto mt-16 max-w-2xl">
          <div
            aria-hidden="true"
            className="absolute left-[27px] top-2 h-[calc(100%-2rem)] w-px bg-burgundy/20 md:left-1/2"
          />
          <ol className="space-y-10">
            {schedule.map((item, i) => (
              <FadeIn key={item.time} delay={i * 0.06}>
                <li className="relative flex items-start gap-6 md:grid md:grid-cols-2 md:gap-10">
                  <div className="hidden md:block md:pr-10 md:text-right">
                    {i % 2 === 0 && <TimelineCopy item={item} />}
                  </div>

                  <span
                    aria-hidden="true"
                    className="relative z-10 mt-1 flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full bg-burgundy md:absolute md:left-1/2 md:mt-0 md:-translate-x-1/2"
                  />

                  <div className="md:pl-10">
                    <div className="md:hidden">
                      <TimelineCopy item={item} />
                    </div>
                    <div className="hidden md:block">
                      {i % 2 !== 0 && <TimelineCopy item={item} />}
                    </div>
                  </div>
                </li>
              </FadeIn>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}

function TimelineCopy({
  item,
}: {
  item: { time: string; title: string; note: string };
}) {
  return (
    <div>
      <p className="font-body text-xs uppercase tracking-widest2 text-burgundy-400">
        {item.time}
      </p>
      <h3 className="mt-1 font-display text-2xl font-medium text-burgundy">
        {item.title}
      </h3>
      <p className="mt-1 font-body text-sm text-ink/70">{item.note}</p>
    </div>
  );
}
