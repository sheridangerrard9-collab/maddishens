import { FadeIn } from "./FadeIn";

/**
 * Outfit inspiration images. To swap in real photos, just replace the `src`
 * values below (or point them at your own hosted images / a Vercel Blob
 * store) — the masonry layout adapts automatically to each image's aspect
 * ratio via CSS columns, so no dimension bookkeeping is required.
 */
const moodImages = [
  { src: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=800&auto=format&fit=crop", alt: "Flowing cream linen dress" },
  { src: "https://images.unsplash.com/photo-1483985988355-763728e1935b?q=80&w=800&auto=format&fit=crop", alt: "Neutral tone accessories flat lay" },
  { src: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?q=80&w=800&auto=format&fit=crop", alt: "Soft summer dress detail" },
  { src: "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?q=80&w=800&auto=format&fit=crop", alt: "Editorial styling inspiration" },
  { src: "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?q=80&w=800&auto=format&fit=crop", alt: "Elegant sandals and jewellery" },
  { src: "https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?q=80&w=800&auto=format&fit=crop", alt: "Relaxed European summer outfit" },
];

export function MoodBoard() {
  return (
    <section id="wearing" className="bg-burgundy py-28 text-cream md:py-36">
      <div className="mx-auto max-w-editorial px-6 md:px-10">
        <FadeIn className="mx-auto max-w-2xl text-center">
          <span className="eyebrow !text-babyblue-300">Style guide</span>
          <h2 className="mt-4 font-display text-4xl font-medium text-cream md:text-6xl">
            What We&rsquo;re Wearing
          </h2>
          <p className="mt-5 font-body text-base text-cream/75 md:text-lg">
            Think elevated, feminine, celebratory and effortlessly chic.
          </p>
        </FadeIn>

        {/* Pinterest-style masonry via CSS columns — genuinely responsive
            without needing to know image dimensions ahead of time. */}
        <FadeIn delay={0.15} className="mt-16">
          <div className="columns-2 gap-4 sm:columns-3 [column-fill:balance]">
            {moodImages.map((img, i) => (
              <div
                key={img.src}
                className="mb-4 break-inside-avoid overflow-hidden rounded-2xl shadow-soft"
                style={{ marginTop: i % 3 === 1 ? "1.5rem" : 0 }}
              >
                <img
                  src={img.src}
                  alt={img.alt}
                  loading="lazy"
                  className="h-auto w-full object-cover transition-transform duration-500 ease-out hover:scale-[1.04]"
                />
              </div>
            ))}
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
