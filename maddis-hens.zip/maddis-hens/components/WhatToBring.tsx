import { Footprints, Moon, Sparkles, Camera, Music2 } from "lucide-react";
import { FadeIn } from "./FadeIn";

const items = [
  { icon: Footprints, label: "Comfortable shoes", note: "For the grass & the dance floor" },
  { icon: Moon, label: "Overnight essentials", note: "If you're staying over" },
  { icon: Sparkles, label: "Positive energy", note: "The only strict dress code" },
  { icon: Camera, label: "A camera", note: "Disposable ones welcome" },
  { icon: Music2, label: "Dancing shoes", note: "The night ends on the floor" },
];

export function WhatToBring() {
  return (
    <section className="bg-sand/60 py-28 md:py-36">
      <div className="mx-auto max-w-editorial px-6 md:px-10">
        <FadeIn className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Come prepared</span>
          <h2 className="section-heading mt-4">What to Bring</h2>
        </FadeIn>

        <div className="mt-16 grid grid-cols-2 gap-5 sm:grid-cols-3 md:grid-cols-5">
          {items.map((item, i) => (
            <FadeIn key={item.label} delay={i * 0.06}>
              <div className="flex h-full flex-col items-center rounded-2xl bg-cream p-6 text-center shadow-card">
                <item.icon
                  className="h-6 w-6 text-burgundy/70"
                  strokeWidth={1.4}
                  aria-hidden="true"
                />
                <p className="mt-4 font-display text-lg font-medium text-burgundy">
                  {item.label}
                </p>
                <p className="mt-1 font-body text-xs text-ink/60">{item.note}</p>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}
