import { FadeIn } from "./FadeIn";
import { BowIllustration } from "./LineArt";

export function AboutDay() {
  return (
    <section id="about" className="relative bg-cream py-28 md:py-36">
      <div className="mx-auto grid max-w-editorial grid-cols-1 items-center gap-14 px-6 md:grid-cols-2 md:px-10 md:gap-20">
        <FadeIn>
          <div className="relative aspect-[4/5] w-full overflow-hidden rounded-[2rem] bg-sand shadow-card">
            {/* Editorial placeholder image — swap the src for a real photo of Maddi */}
            <img
              src="https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1200&auto=format&fit=crop"
              alt="Soft editorial photograph capturing the celebratory spirit of the day"
              className="h-full w-full object-cover"
              loading="lazy"
            />
          </div>
        </FadeIn>

        <FadeIn delay={0.15}>
          <span className="eyebrow">About the day</span>
          <h2 className="section-heading mt-4 text-4xl md:text-5xl">
            One last celebration, just for her
          </h2>
          <div className="mt-6 space-y-5 font-body text-base leading-relaxed text-ink/80 md:text-lg">
            <p>
              Before Maddi says &ldquo;I do&rdquo;, her nearest and dearest are
              gathering for a day built entirely around her — long lunches,
              good champagne, and the kind of laughter that leaves your face
              aching by sunset.
            </p>
            <p>
              You&rsquo;re here because you&rsquo;re one of the people who
              made her story what it is. No games with cheap props, no
              plastic tiaras — just an elegant, unhurried day among friends,
              in a setting as lovely as the company.
            </p>
            <p>
              Expect soft linen, golden light, a glass that never quite
              empties, and a guest of honour who cannot wait to see you
              there.
            </p>
          </div>
          <BowIllustration className="mt-8 h-10 w-16 text-burgundy/40" />
        </FadeIn>
      </div>
    </section>
  );
}
