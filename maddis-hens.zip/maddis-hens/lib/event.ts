/**
 * Single source of truth for event details.
 * Pulls from env vars where provided, with sensible fallbacks, so the host
 * can update the date/time/location from Vercel's dashboard without
 * touching code.
 */
export const event = {
  title: "Maddi's Hens",
  date: process.env.NEXT_PUBLIC_EVENT_DATE ?? "2026-11-14",
  startTime: process.env.NEXT_PUBLIC_EVENT_START_TIME ?? "11:00",
  endTime: process.env.NEXT_PUBLIC_EVENT_END_TIME ?? "22:00",
  location:
    process.env.NEXT_PUBLIC_EVENT_LOCATION ?? "The Vinehouse, Red Hill South, VIC",
  dressCode: "Elevated linen & sundresses — soft neutrals encouraged",
  contactName: "Ellie (Maid of Honour)",
  contactEmail: "ellie@maddishens.com",
  contactPhone: "+61 400 000 000",
};

/** Combine date + time into a Date object for countdowns / calendar files. */
export function getEventDateTime(): Date {
  return new Date(`${event.date}T${event.startTime}:00`);
}

/** Format the event date as "Saturday, 14 November 2026". */
export function getFormattedDate(): string {
  return getEventDateTime().toLocaleDateString("en-AU", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

/** Build a .ics calendar file string for "Save to Calendar". */
export function buildIcsFile(): string {
  const start = getEventDateTime();
  const end = new Date(`${event.date}T${event.endTime}:00`);
  const fmt = (d: Date) =>
    d.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";

  return [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Maddi's Hens//RSVP//EN",
    "BEGIN:VEVENT",
    `UID:maddis-hens-${Date.now()}@maddishens.com`,
    `DTSTAMP:${fmt(new Date())}`,
    `DTSTART:${fmt(start)}`,
    `DTEND:${fmt(end)}`,
    `SUMMARY:${event.title}`,
    `LOCATION:${event.location}`,
    "DESCRIPTION:A day of celebration, champagne, laughter and unforgettable memories.",
    "END:VEVENT",
    "END:VCALENDAR",
  ].join("\r\n");
}
